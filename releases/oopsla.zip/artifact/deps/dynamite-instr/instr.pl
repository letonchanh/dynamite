#!/usr/bin/perl
use File::Spec;
use Cwd;

sub runc { 
    my ($cmd) = @_; 
    # print "+ $cmd\n"; 
    my $r = qx{$cmd}; 
    print $r; 
}

die "usage:
    instr.pl vtrace <input.c> <output.c> <#bound>
or
    instr.pl validate <input.c> <output.c> <x-y|x|n>

       where the 3rd argument is a |-delimited list of rank functions (no <>'s)
    " unless $#ARGV == 3;

my ($xform,$inf,$outf,$arg) = @ARGV;
die unless $xform =~ m/^(vtrace|validate)$/;

$inf = File::Spec->rel2abs($inf);
$outf = File::Spec->rel2abs($outf);

# chdir('/tools/dynamo-instr/');
# my $cwd = getcwd;
# my $dynamo_instr_dir = "$cwd/../deps/dynamo-instr";
my $dynamo_instr_dir = "/repo/dynamo/deps/dynamo-instr";
if ($xform eq 'vtrace') {
    runc(qq{$dynamo_instr_dir/src/cil/bin/cilly --gcc=/usr/bin/gcc-5 --save-temps -D HAPPY_MOOD --dotransform $inf --bnd=$arg});
} else {
    runc(qq{$dynamo_instr_dir/src/cil/bin/cilly --gcc=/usr/bin/gcc-5 --save-temps -D HAPPY_MOOD --dovalidate $inf --vloop=vloop --ranks=$arg});
}

# CIL emits the output in the CWD
my ($volume,$directories,$file) = File::Spec->splitpath( $inf );
#my $t = $inf; $t =~ s/\.c$/\.cil\.c/;
 
my $t = $file; $t =~ s/\.c$/\.cil\.c/;
die "can't find $t in CWD $cwd\n" unless -e $t;
runc(qq{cp $t $outf});
# print "Transformation complete. Resulting file:\n$outf\n";


__DATA__
    runc(qq{clang-9 -emit-llvm -S $inf -o $outf.tmp.ll});
>>>>>>> 064d47558af87b6fe142feb795abef337f89fd6b
runc(qq{opt-9 -load $LIB_TRANSFORM -MyLoopPass -LoopTransformPass  -S < $outf.tmp.ll > $outf});
print "Transformation complete. Resulting file:\n$outf\n";
