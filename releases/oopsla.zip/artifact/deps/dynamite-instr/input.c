#include <stdio.h>

int __VERIFIER_nondet_int(void){return 0;}
void __VERIFIER_error(void){}

int main() {
   int x = 5, y = 1, z = 3;
   if (x > 0) {
     int y = z + 1;
     while (x > z) {
       x = x - z;
     }
   }
   return 0;
}
