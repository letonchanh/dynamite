#include "mergeinit2.h"

int main(){
	return(table[0]());
}
