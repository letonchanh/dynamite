
extern int f1(void);
