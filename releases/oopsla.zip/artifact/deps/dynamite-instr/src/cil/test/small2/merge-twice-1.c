// merge-twice: testcase of merging merged results

int foo()
{
  return 3;
}
