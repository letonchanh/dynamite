
extern int f3(void);
