// call a function twice, which does printf of a literal string

#include <stdio.h>    // printf

void pr()
{
  printf("hi there\n");
}

int main()
{
  pr();
  pr();
  return 0;
}
