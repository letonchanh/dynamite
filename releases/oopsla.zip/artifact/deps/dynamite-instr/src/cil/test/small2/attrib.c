struct mpc_config_bus
{
	unsigned char mpc_bustype[6] __attribute((packed));
};

int main () {
 return 0;
}
