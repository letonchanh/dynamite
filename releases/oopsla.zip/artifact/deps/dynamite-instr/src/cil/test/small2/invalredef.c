

extern int wchgat(const void *);

int wchgat(const void *opts __attribute__((unused)) )
{
      return 1;
}

int main () {
  return 0;
}
