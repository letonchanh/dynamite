
int f3(void)
{
	return(3);
}


