
int f1(void)
{
	return(1);
}


