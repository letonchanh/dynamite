// initedextern.c
// from sac at stevechamberlain dot com

// claim is that this is common enough that we should support it

extern int foo = 3;

int main()
{
  return 0;
}
