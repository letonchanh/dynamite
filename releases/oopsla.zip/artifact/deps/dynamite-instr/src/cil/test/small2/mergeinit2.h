
extern int (*table[2])();
