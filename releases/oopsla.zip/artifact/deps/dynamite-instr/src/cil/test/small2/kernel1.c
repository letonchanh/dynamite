
DECLARE_WAIT_QUEUE_HEAD(log_wait);



int main () {
 return 0;
}
  

