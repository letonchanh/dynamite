open Pretty
open Cil
open Feature
open Trace
open Printf

module E = Errormsg
module L = List

let loop_pos = ref 0
let ranking_function_list = ref []
(* let outfile = ref "" *)

let main_name = "main"
let error_name = "__VERIFIER_error"
let nondet_name = "__VERIFIER_nondet_int"
let cil_tmp_prefix = "__cil_tmp"
let tvar_prefix = "t"
let dup_var_name = "dup"
let rank_prefix = "r"

let contains s prefix =
  let prefix_len = String.length prefix in
  String.length s >= prefix_len &&
  String.sub s 0 prefix_len = prefix

let is_vfunc vname vprefix =
  contains vname vprefix

let is_cil_tmp vname =
  contains vname cil_tmp_prefix

let v2e (v: lval): exp = Lval v

let vi2e (vi: varinfo): exp = Lval (var vi)

let mk_fun_typ ?(is_var_arg=false) ?(attrs=[]) (rt : typ) (args : (string * typ) list): typ =
  TFun(rt, Some (L.map (fun a -> (fst a, snd a, [])) args), is_var_arg, attrs)

let mk_fundec (fname: string) (ftype: typ): fundec =
  let fd = emptyFunction fname in
  let () = setFunctionTypeMakeFormals fd ftype in
  fd

let mk_Call ?(ftype=TVoid []) ?(av=None) (fname: string) args : instr = 
  let fvar = makeVarinfo true fname ftype in
  Call(av, vi2e fvar, args, !currentLoc)

let mk_If ?(else_block=None) (cond: exp) (if_block: block) : stmt =
  mkStmt (If(cond, 
             if_block, 
             (match else_block with None -> mkBlock [] | Some b -> b),
             !currentLoc))

let only_functions (fn : fundec -> location -> unit) (g : global) : unit = 
  match g with
  | GFun(f, loc) -> fn f loc
  | _ -> ()

let find_fun (ast: file) (check: fundec -> bool): fundec = 
  let fd = 
    foldGlobals ast 
      (fun r g -> match r, g with 
        | Some _, _ -> r
        | None, GFun (f, _) when check f -> Some f
        | _ -> r
      ) None in
  match fd with
  | Some f -> f
  | None -> E.s (E.error "fun not found in '%s'!" ast.fileName)

let write_src ?(use_stdout:bool=false)
    ?(filename:string="") (ast: file): unit = 
  let df oc = dumpFile defaultCilPrinter oc filename ast in
  if use_stdout then df stdout 
  else (
    let fout = open_out filename in
    df fout;
    close_out fout
  )

let split_ranking_functions s =
  if s = "" then []
  else String.split_on_char '|' s

let mk_ranking_function_def_macros params ranking_function_list =
  let untyped_params = 
    List.map (fun vi -> vi.vname) params 
    |> String.concat ", "
  in
  let _, macros = List.fold_left (fun (i, ms) r ->
      let r_macro =
        "#define " ^ (rank_prefix ^ (string_of_int i)) ^ 
        "(" ^ untyped_params ^ ") " ^
        "(" ^ r ^ ")" 
      in
      (i + 1, ms @ [r_macro])
    ) (1, []) ranking_function_list
  in
  let all_macros = String.concat "\n" macros in
  GText (all_macros)

class annotate_loop_in_fd_visitor ast (fd: fundec) loop_pos ranking_function_list = object(self)
  inherit nopCilVisitor

  method private mk_aux_vars local_vars =
    (** int x, y, z; *)
    (* let local_vars = fd.slocals in *)
    (** int tx, ty, tz; *)
    let local_tvars = List.map (fun vi -> 
        makeLocalVar fd (tvar_prefix ^ vi.vname) vi.vtype) local_vars in
    (** int dup; *)
    let dup_var = makeLocalVar fd dup_var_name intType in
    local_tvars, dup_var

  method private mk_if_dup_stmt dup_var local_tvars local_vars num_ranks =
    let mk_rank_conds num_ranks =
      let rec helper i =
        if i <= num_ranks then
          let ranki_name = rank_prefix ^ (string_of_int i) in
          let tri = makeTempVar fd intType in
          let c_tri = 
            mk_Call ~av:(Some (var tri)) 
              ranki_name
              (List.map vi2e local_tvars) 
            |> mkStmtOneInstr
          in
          let ri = makeTempVar fd intType in
          let c_ri = 
            mk_Call ~av:(Some (var ri)) 
              ranki_name
              (List.map vi2e local_vars)
            |> mkStmtOneInstr
          in
          let ranki_decr_cond = BinOp(Gt, vi2e tri, vi2e ri, intType) in
          let ranki_bnd_cond = BinOp(Ge, vi2e tri, zero, intType) in
          let ranki_cond = BinOp(LAnd, ranki_decr_cond, ranki_bnd_cond, intType) in
          (ranki_cond, c_tri, c_ri)::(helper (i + 1))
        else []
      in
      helper 1
    in

    let mk_rank_if_block rank_conds =
      let rec helper rank_conds =
        match rank_conds with
        | [] -> 
          let error_func_type = mk_fun_typ voidType [] in
          let error_call = mk_Call ~ftype:error_func_type error_name [] in
          mkBlock [mkStmtOneInstr error_call]
        | (r, tc, c)::rs ->
          let rs_if_block = helper rs in
          let if_stmt = mk_If (UnOp(LNot, r, intType)) rs_if_block in
          mkBlock [tc; c; if_stmt]
      in
      (* match rank_conds with
      | [] -> mkBlock []
      | _ -> helper rank_conds *)
      helper rank_conds
    in

    let dup_cond = vi2e dup_var in
    let rank_conds = mk_rank_conds num_ranks in
    let if_block = mk_rank_if_block rank_conds in
    mk_If dup_cond if_block

  method private mk_if_not_dup_stmt dup_var local_tvars local_vars =
    let not_dup_cond = UnOp(LNot, vi2e dup_var, intType) in
    let nondet_var = makeTempVar fd intType in
    let nondet_call = 
      mk_Call ~av:(Some (var nondet_var)) nondet_name []
      |> mkStmtOneInstr
    in
    let if_cond = BinOp(LAnd, not_dup_cond, vi2e nondet_var, intType) in
    let dup_assign_stmt = mkStmtOneInstr (Set(var dup_var, one, !currentLoc)) in
    let tvar_assign_stmts =
      List.map2 (fun tvi vi -> 
        mkStmtOneInstr (Set(var tvi, vi2e vi, !currentLoc))
      ) local_tvars local_vars
    in
    let if_stmt = mk_If if_cond (mkBlock (tvar_assign_stmts @ [dup_assign_stmt])) in
    mkStmt (Block (mkBlock [nondet_call; if_stmt]))

  method vstmt (s: stmt) =
    let action s =
      match s.skind with
      | Loop(b, loc, co, bo) when loc.line = loop_pos ->
        let _, local_vars = List.partition (fun v -> is_cil_tmp v.vname) (fd.sformals @ fd.slocals) in
        let ranking_function_def_macros = mk_ranking_function_def_macros local_vars ranking_function_list in 
        let error_defn = GText("extern void __VERIFIER_error(void);") in
        ast.globals <- ranking_function_def_macros::error_defn::ast.globals;

        let num_ranks = List.length ranking_function_list in
        let local_tvars, dup_var = self#mk_aux_vars local_vars in
        (** dup = 0; *)
        let dup_init_stmt = mkStmtOneInstr (Set(var dup_var, zero, !currentLoc)) in
        let if_dup_stmt = self#mk_if_dup_stmt dup_var local_tvars local_vars num_ranks in
        let if_not_dup_stmt = self#mk_if_not_dup_stmt dup_var local_tvars local_vars in
        (* b.bstmts <- if_dup_stmt::b.bstmts; *)
        b.bstmts <- (List.hd b.bstmts)::
                    if_dup_stmt::
                    if_not_dup_stmt::
                    (List.tl b.bstmts);
        mkStmt (Block (mkBlock [dup_init_stmt; s]))
      | _ -> s
    in
    ChangeDoChildrenPost(s, action)
end

let annotate_loop_in_fd ast loop_pos ranking_function_list fd pos =
  let alb = new annotate_loop_in_fd_visitor ast fd loop_pos ranking_function_list in
  ignore (visitCilFunction alb fd);
  ()

let feature = { 
  fd_name = "validate";
  fd_enabled = false;
  fd_description = "generation of code to validate the loops";
  fd_extraopt = [("--pos", Arg.Set_int loop_pos, "<n> The position of the loop to validate");
                 ("--ranks", Arg.String (fun s -> ranking_function_list := split_ranking_functions s), 
                    "<r1|...|rn> list of ranking functions to validate");
                 (* ("--voutput", Arg.Set_string outfile, "output file") *)
                ];
  fd_doit = (function (f: file)  ->
    Cil.lineDirectiveStyle := None; (* reduce code, remove all junk stuff *)
    Cprint.printLn := false; (* don't print line *)
    (* for Cil to retain &&, ||, ?: instead of transforming them to If stmts *)
    Cil.useLogicalOperators := true;
    Cil.oldstyleExternInline := true;

    iterGlobals f (only_functions (annotate_loop_in_fd f !loop_pos !ranking_function_list));
    (* write_src ~filename:!outfile f *)
  );
  fd_post_check = true;
}

let () = Feature.register feature


