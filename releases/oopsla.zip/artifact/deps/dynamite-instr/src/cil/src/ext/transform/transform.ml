open Pretty
open Cil
open Feature
open Trace
open Printf

module E = Errormsg
module H = Hashtbl
module S = String
module L = List

(* module Str = struct 
   type t = string 
   
   let compare = compare
 end

module StrSet = Set.Make(Str) *)

let bnd = ref 500
(* let outfile = ref "" *)

let vloop_prefix = "vloop"
let vtrace_prefix = "vtrace"
let mainQ_prefix = "mainQ"
let ptr_prefix = "PTR_"
let cil_tmp_prefix = "__cil_tmp"
let nondet_int_name = "__VERIFIER_nondet_int"
let nondet_uint_name = "__VERIFIER_nondet_unsigned_int"
let exit_name = "exit"
let main_name = "main"
let preloop_label = "1"
let inloop_label = "2"
let postloop_label = "3"
let transrel_label = "4"

let v2e (v: lval): exp = Lval v

let vi2e (vi: varinfo): exp = Lval (var vi)

let contains s prefix =
  let prefix_len = S.length prefix in
  S.length s >= prefix_len &&
  S.sub s 0 prefix_len = prefix

let is_vfunc vname vprefix =
  contains vname vprefix

let is_vtrace vname =
  is_vfunc vname vtrace_prefix

let is_cil_tmp vname =
  contains vname cil_tmp_prefix

let is_nondet_func vname =
  vname = nondet_int_name || vname = nondet_uint_name

let get_vloop_loc vname =
  if is_vfunc vname vloop_prefix then
    let vloop_prefix_len = S.length vloop_prefix in
    let vloop_loc = S.sub vname 0 (vloop_prefix_len + 1) in
    Some vloop_loc
  else None

let mk_vtrace_name loc label =
  vtrace_prefix ^ label ^ "_" ^ (string_of_int loc.line)

let mk_fun_typ ?(is_var_arg=false) ?(attrs=[]) (rt : typ) (args : (string * typ) list): typ =
  TFun(rt, Some (L.map (fun a -> (fst a, snd a, [])) args), is_var_arg, attrs)

let mk_fundec (fname: string) (ftype: typ): fundec =
  let fd = emptyFunction fname in
  let () = setFunctionTypeMakeFormals fd ftype in
  fd

let mk_Call ?(ftype=TVoid []) ?(av=None) (fname: string) args : instr = 
  let fvar = makeVarinfo true fname ftype in
  Call(av, vi2e fvar, args, !currentLoc)

let only_functions (fn : fundec -> location -> unit) (g : global) : unit = 
  match g with
  | GFun(f, loc) -> fn f loc
  | _ -> ()

let find_fun (ast: file) (check: fundec -> bool): fundec = 
  let fd = 
    foldGlobals ast 
      (fun r g -> match r, g with 
        | Some _, _ -> r
        | None, GFun (f, _) when check f -> Some f
        | _ -> r
      ) None in
  match fd with
  | Some f -> f
  | None -> E.s (E.error "fun not found in '%s'!" ast.fileName)

let write_src ?(use_stdout:bool=false)
    ?(filename:string="") (ast: file): unit = 
  let df oc = dumpFile defaultCilPrinter oc filename ast in
  if use_stdout then df stdout 
  else (
    let fout = open_out filename in
    df fout;
    close_out fout
  )

let rec add_global_before_func func_name g gs =
  match gs with
  | [] -> [g]
  | ((GFun (fd, _)) as hd)::tl when fd.svar.vname = func_name -> g::hd::tl
  | hd::tl -> hd :: (add_global_before_func func_name g tl)

class instrument_vloop_visitor ast (fd: fundec) = object(self)
  inherit nopCilVisitor

  method private mk_vtrace_call_instrs loc =
    let vtrace_preloop_name = mk_vtrace_name loc preloop_label in 
    let vtrace_inloop_name = mk_vtrace_name loc inloop_label in 
    let vtrace_postloop_name = mk_vtrace_name loc postloop_label in 
    let vtrace_transrel_name = mk_vtrace_name loc transrel_label in 
    let vtrace_fd = find_fun ast (fun fd -> fd.svar.vname = vtrace_preloop_name) in
    let vtrace_args = List.map (fun v -> vi2e v) vtrace_fd.sformals in
    let vtrace_type = vtrace_fd.svar.vtype in
    let vtrace_preloop_call = mk_Call ~ftype:vtrace_type vtrace_preloop_name vtrace_args in
    let vtrace_inloop_call = mk_Call ~ftype:vtrace_type vtrace_inloop_name vtrace_args in
    let vtrace_postloop_call = mk_Call ~ftype:vtrace_type vtrace_postloop_name vtrace_args in
    let vtrace_transrel_call = mk_Call ~ftype:vtrace_type vtrace_transrel_name vtrace_args in
    vtrace_fd, vtrace_preloop_call, vtrace_inloop_call, vtrace_postloop_call, vtrace_transrel_call

  method private mk_instrument_stmts loc (fd: fundec) =
    let vtrace_fd, vtrace_preloop_call, vtrace_inloop_call, vtrace_postloop_call, vtrace_transrel_call = 
      self#mk_vtrace_call_instrs loc in

    let vis, ptr_dereference_stmts = 
      List.map2 (fun vi pi -> 
        let v = makeLocalVar fd vi.vname vi.vtype in
        let p = Lval (mkMem (vi2e pi) NoOffset) in
        v, mkStmtOneInstr (Set (var v, p, !currentLoc))
      ) vtrace_fd.sformals fd.sformals 
      |> List.split
    in
    let ptr_update_stmts = List.map2 (fun vi pi -> 
        let p = mkMem (vi2e pi) NoOffset in
        mkStmtOneInstr (Set (p, vi2e vi, !currentLoc))
      ) vis fd.sformals in
    let preloop_vtrace_call_stmt = mkStmtOneInstr vtrace_preloop_call in
    let bnd_var = var (makeLocalVar fd "bnd" intType) in
    let counter_var = var (makeLocalVar fd "counter" intType) in
    (* bnd = 500 *)
    let bnd_init_stmt = mkStmtOneInstr (Set(bnd_var, integer !bnd, !currentLoc)) in
    (* counter = 0 *)
    let counter_init_stmt = mkStmtOneInstr (Set(counter_var, zero, !currentLoc)) in
    (* if (counter >= bnd) break else counter++ *)
    let counter_ge_bnd_cond = BinOp(Ge, v2e counter_var, v2e bnd_var, intType) in
    (* let if_break_block = mkBlock [(mkStmt (Break(!currentLoc)))] in *)
    let exit_func_type = mk_fun_typ voidType [("__status", intType)] in
    let exit_stmt = mkStmtOneInstr (mk_Call ~ftype:exit_func_type "exit" [zero]) in
    let if_break_block = mkBlock [exit_stmt] in
    let else_incr_block = mkBlock [mkStmtOneInstr (Set(counter_var, increm (v2e counter_var) 1, !currentLoc))] in
    let inloop_if_stmt = mkStmt (If(counter_ge_bnd_cond, if_break_block, else_incr_block, !currentLoc)) in
    
    let inloop_vtrace_call_stmt = mkStmtOneInstr vtrace_inloop_call in

    let postloop_vtrace_call_stmt = mkStmtOneInstr vtrace_postloop_call in

    let transrel_vtrace_call_stmt = mkStmtOneInstr vtrace_transrel_call in

    (* if (counter < bnd) *)
    let counter_lt_bnd_cond = BinOp(Lt, v2e counter_var, v2e bnd_var, intType) in
    let postloop_if_stmt = mkStmt (If(counter_lt_bnd_cond, mkBlock [postloop_vtrace_call_stmt], mkBlock [], !currentLoc)) in
    ptr_dereference_stmts, ptr_update_stmts,
    preloop_vtrace_call_stmt, bnd_init_stmt, counter_init_stmt, (* Preloop instrumentation *)
    inloop_if_stmt, inloop_vtrace_call_stmt, transrel_vtrace_call_stmt, (* Inloop instrumentation *)
    postloop_if_stmt (* Postloop instrumentation *)

  method vstmt (s: stmt) =
    let action s =
      match s.skind with
      | Loop(b, loc, co, bo) ->
        let ptr_dereference_stmts, ptr_update_stmts,
            preloop_vtrace_call_stmt, bnd_init_stmt, counter_init_stmt, 
            inloop_if_stmt, inloop_vtrace_call_stmt, transrel_vtrace_call_stmt,
            postloop_if_stmt = self#mk_instrument_stmts loc fd in
        let () = b.bstmts <-  ((List.hd b.bstmts) :: 
                              inloop_if_stmt :: 
                              inloop_vtrace_call_stmt :: 
                              (List.tl b.bstmts)) @ 
                              [transrel_vtrace_call_stmt] in
        let nb = mkBlock  (ptr_dereference_stmts @
                           [preloop_vtrace_call_stmt; 
                            bnd_init_stmt; 
                            counter_init_stmt; 
                            mkStmt s.skind; 
                            postloop_if_stmt] @
                           ptr_update_stmts) in
        let () = s.skind <- Block nb in
        s
      | _ -> s
    in
    ChangeDoChildrenPost(s, action)
end

class create_void_return_visitor = object(self)
  inherit nopCilVisitor

  method vstmt (s: stmt) =
    let action s =
      match s.skind with
      | Return (Some _, loc) -> 
        s.skind <- Return (None, loc);
        s
      | _ -> s
    in
    ChangeDoChildrenPost(s, action)
end

class mk_call_graph_visitor = object(self)
  inherit nopCilVisitor

  val mutable callee_list = []

  method vinst (i: instr) =
    begin match i with
      | Call (_, (Lval (Var fn, _)), _, _) ->
        if not (is_nondet_func fn.vname) && not (is_vtrace fn.vname) then
          callee_list <- callee_list @ [fn.vname]
        else ()
      | _ -> ()
    end;
    DoChildren

  method get_callee_list () =
    callee_list
end

class collect_vars_visitor = object(self)
  inherit nopCilVisitor

  val mutable vars = []

  method vvrbl (vi: varinfo) =
    (if not (List.mem vi.vname vars) then
      vars <- vars @ [vi.vname]
    else ());
    SkipChildren

  method get_vars () =
    vars
end

let collect_vars visit_func c =
  let cvs = new collect_vars_visitor in
  ignore (visit_func (cvs :> nopCilVisitor) c);
  cvs#get_vars ()

let collect_vars_exp (e: exp) =
  collect_vars visitCilExpr e

let collect_vars_block (b: block) =
  collect_vars visitCilBlock b

class remove_nondet_init_visitor (fd: fundec) = object(self)
  inherit nopCilVisitor

  val mutable initialized_vars = []
  val mutable nondet_vars = []

  method vinst (i: instr) =
    match i with
    | Call (v_opt, (Lval (Var fn, _)), _, _) ->
      (match v_opt with
      | Some (Var v, _) when not (List.mem v.vname initialized_vars) ->
        initialized_vars <- initialized_vars @ [v.vname];
        if is_nondet_func fn.vname then (
          nondet_vars <- nondet_vars @ [v.vname]; 
          if List.exists (fun vi -> vi.vname = v.vname) fd.sformals
          then ChangeTo []
          else DoChildren)
        else DoChildren
      | _ -> DoChildren)
    | Set ((Var v, _), e, _) when not (List.mem v.vname initialized_vars) ->
      initialized_vars <- initialized_vars @ [v.vname];
      let vs = collect_vars_exp e in
      if List.length vs > 0 && 
         List.for_all (fun v -> List.mem v nondet_vars && is_cil_tmp v) vs
      then ChangeTo []
      else DoChildren
    | _ -> DoChildren

  method get_initialized_vars () =
    initialized_vars
end

class collect_important_local_vars_visitor = object(self)
  inherit nopCilVisitor

  val mutable important_local_vars = []
  val mutable initialized_vars = []

  method vinst (i: instr) =
    (match i with
    | Call (v_opt, _, es, _) ->
      (match v_opt with
      | Some (Var v, _) when not (List.mem v.vname initialized_vars) ->
        initialized_vars <- initialized_vars @ [v.vname];
        if List.for_all (fun e -> (collect_vars_exp e) = []) es then
          important_local_vars <- important_local_vars @ [v.vname]
        else ()
      | _ -> ())
    | Set ((Var v, _), e, _) when not (List.mem v.vname initialized_vars) ->
      initialized_vars <- initialized_vars @ [v.vname];
      let vs = collect_vars_exp e in
      if List.length vs > 0 && 
         List.for_all (fun v -> List.mem v important_local_vars && is_cil_tmp v) vs then
        important_local_vars <- important_local_vars @ [v.vname]
      else ()
    | _ -> ());
    DoChildren

  method get_important_local_vars () =
    important_local_vars

  method get_initialized_vars () =
    initialized_vars
end

class loop_to_vloop_visitor ast fd = object(self)
  inherit nopCilVisitor

  (* val mutable vloop_pure_params = []  *)

  method private mk_vloop_global vloop_name vloop_type vloop_local_vars vloop_body =
    let fd = mk_fundec vloop_name vloop_type in
    fd.slocals <- vloop_local_vars;
    fd.sbody <- mkBlock [vloop_body];
    GFun(fd, !currentLoc)

  method private mk_vtrace_globals loc params =
    let vtrace_param_types = L.map (fun vi -> (vi.vname, vi.vtype)) params in
    let vtrace_fun_typ = mk_fun_typ voidType vtrace_param_types in
    let vtrace_fds = L.map 
        (fun label -> mk_fundec (mk_vtrace_name loc label) vtrace_fun_typ) 
        [preloop_label; inloop_label; postloop_label; transrel_label] in
    L.map (fun fd -> GFun(fd, !currentLoc)) vtrace_fds

  method vstmt (s: stmt) =
    let action s =
      match s.skind with
      | Loop(b, loc, co, bo) ->
        let vloop_name = vloop_prefix ^ "_" ^ (string_of_int loc.line) in
        let block_local_vars = collect_vars_block b in
        let fd_vars = fd.sformals @ fd.slocals in
        let vloop_vars = List.filter (fun vi -> List.mem vi.vname block_local_vars) fd_vars in
        let vloop_params, vloop_tmp_vars = List.partition (fun vi -> not (is_cil_tmp vi.vname)) vloop_vars in
        (* vloop_pure_params <- vloop_params; *)

        let vtrace_globals = self#mk_vtrace_globals loc vloop_params in
        ast.globals <- vtrace_globals @ ast.globals;

        let vloop_param_types = L.map (fun vi -> (ptr_prefix ^ vi.vname, TPtr(vi.vtype, []))) vloop_params in
        let vloop_type = mk_fun_typ voidType vloop_param_types in
        let vloop_global = self#mk_vloop_global vloop_name vloop_type vloop_tmp_vars s in
        ast.globals <- add_global_before_func main_name vloop_global ast.globals;

        let vloop_args = List.map (fun vi -> mkAddrOf (var vi)) vloop_params in
        let vloop_call_stmt = mkStmtOneInstr (mk_Call ~ftype:vloop_type vloop_name vloop_args) in
        vloop_call_stmt
      | _ -> s
    in
    ChangeDoChildrenPost(s, action)

  (* method get_vloop_pure_params () =
    vloop_pure_params *)
end

(** A important var (to be considered as a parameter of mainQ) 
    is a var which is not initialized by another var or constant *)
let collect_important_local_vars (main_fd: fundec) =
  let cilv = new collect_important_local_vars_visitor in
  ignore (visitCilBlock (cilv :> nopCilVisitor) main_fd.sbody);
  cilv#get_important_local_vars ()

let loop_to_vloop f fd loc =
  let l_to_vl = new loop_to_vloop_visitor f fd in
  ignore (visitCilFunction (l_to_vl :> nopCilVisitor) fd)

let collect_uninitialized_local_vars (fd: fundec) =
  let cilv = new collect_important_local_vars_visitor in
  ignore (visitCilBlock (cilv :> nopCilVisitor) fd.sbody);
  let initialized_vars = cilv#get_initialized_vars () in
  List.filter (fun vi -> not (List.mem vi.vname initialized_vars)) fd.slocals

let mk_instrumenting_functions f =
  let main_fd = find_fun f (fun fd -> fd.svar.vname = main_name) in
  let local_vars = main_fd.slocals in
  let important_vars = collect_important_local_vars main_fd in
  let tmp_vars, main_vars = List.partition (fun v -> is_cil_tmp v.vname) local_vars in
  let main_param_vars, main_local_vars = List.partition (fun v -> List.mem v.vname important_vars) main_vars in
  let mainQ_type = mk_fun_typ voidType (List.map (fun v -> (v.vname, v.vtype)) main_param_vars) in
  let mainQ_args = main_param_vars in
  let mainQ_local_vars = main_local_vars @ tmp_vars in
  
  (** make vloop and vtrace functions *)
  (* let l_to_vl = fun fd -> new loop_to_vloop_visitor f fd.slocals in *)
  (* let () = ignore (visitCilFunction ((l_to_vl main_fd) :> nopCilVisitor) main_fd) in *)
  let () = iterGlobals f (only_functions (loop_to_vloop f)) in

  (** mk_mainQ *)
  let mainQ_fd = mk_fundec mainQ_prefix mainQ_type in
  let mainQ_call_stmt = mkStmtOneInstr (mk_Call ~ftype:mainQ_type mainQ_prefix (List.map vi2e mainQ_args)) in
  mainQ_fd.slocals <- mainQ_fd.slocals @ mainQ_local_vars;
  mainQ_fd.sbody <- visitCilBlock (new create_void_return_visitor) main_fd.sbody;
  let mainQ_uninitialized_vars = collect_uninitialized_local_vars mainQ_fd in
  let mainQ_uninitialized_var_assign_stmts = List.map (fun vi -> 
      mkStmtOneInstr (Set(var vi, zero, !currentLoc))) mainQ_uninitialized_vars in
  mainQ_fd.sbody.bstmts <- mainQ_uninitialized_var_assign_stmts @ mainQ_fd.sbody.bstmts;
  (* let () = print_endline (String.concat "," (List.map (fun vi -> vi.vname) mainQ_uninitialized_vars)) in *)

  let main_return_stmt =
    let rt, _, _, _ = splitFunctionType main_fd.svar.vtype in
    match rt with
    | TVoid _ -> mkStmt (Return(None, !currentLoc))
    | _ -> mkStmt (Return(Some zero, !currentLoc))
  in
  main_fd.sbody <- mkBlock [mainQ_call_stmt; main_return_stmt];
  let mainQ_global = GFun(mainQ_fd, !currentLoc) in
  f.globals <- add_global_before_func main_name mainQ_global f.globals

let instrument_vloop f (fd: fundec) (loc: location): unit =
  if is_vfunc fd.svar.vname vloop_prefix then
    let vbi = new instrument_vloop_visitor f fd in
    ignore (visitCilFunction vbi fd)
  else ()

let print_call_graph (fd: fundec) (loc: location): unit =
  let mcg = new mk_call_graph_visitor in
  (* ignore (visitCilBlock (mcg :> nopCilVisitor) fd.sbody); *)
  ignore (visitCilFunction (mcg :> nopCilVisitor) fd);
  let callee_list = mcg#get_callee_list () in
  print_endline (fd.svar.vname ^ ": " ^ (String.concat ", " callee_list))

let remove_nondet_init_in_mainQ (f: file): unit =
  let mainQ_fd = find_fun f (fun fd -> is_vfunc fd.svar.vname mainQ_prefix) in
  let rni = new remove_nondet_init_visitor mainQ_fd in
  ignore (visitCilFunction (rni :> nopCilVisitor) mainQ_fd)
  (* let initialized_vars = rni#get_initialized_vars () in
  print_endline (mainQ_fd.svar.vname ^ ": " ^ (String.concat ", " initialized_vars)) *)

let mk_extern_global fname ftyp =
  let vi = makeGlobalVar fname ftyp in
  vi.vstorage <- Extern;
  GVarDecl (vi, !currentLoc)

(** extern void exit(int); *)
let mk_exit_global () =
  let exit_fun_typ = mk_fun_typ voidType [("__status", intType)] in
  mk_extern_global exit_name exit_fun_typ

let mk_nondet_globals () =
  let nondet_int_globals = mk_extern_global nondet_int_name (mk_fun_typ intType []) in
  let nondet_uint_globals = mk_extern_global nondet_uint_name (mk_fun_typ uintType []) in
  [nondet_int_globals; nondet_uint_globals]

let feature = { 
  fd_name = "transform";
  fd_enabled = false;
  fd_description = "Instrumentation for Dynamite tool";
  fd_extraopt = [("--bnd", Arg.Set_int bnd, "<n> get the upperbound of # loop iterations, default = 500");
                 (* ("--toutput", Arg.Set_string outfile, "output file") *)
                ];
  fd_doit = (function (f: file)  ->
    Cil.lineDirectiveStyle := None; (* reduce code, remove all junk stuff *)
    Cprint.printLn := false; (* don't print line *)
    (* for Cil to retain &&, ||, ?: instead of transforming them to If stmts *)
    Cil.useLogicalOperators := true;

    let exit_global = mk_exit_global () in
    let nondet_globals = mk_nondet_globals () in

    f.globals <- nondet_globals @ (exit_global::f.globals);

    mk_instrumenting_functions f;
    remove_nondet_init_in_mainQ f;
    (** Instrumenting vloop's body *)
    iterGlobals f (only_functions (instrument_vloop f));
    iterGlobals f (only_functions print_call_graph);
    
    (* write_src ~use_stdout:true ~filename:!outfile f *)
  );
  fd_post_check = true;
}

let () = Feature.register feature


