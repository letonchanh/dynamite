#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/Type.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/Constant.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Transforms/IPO/PassManagerBuilder.h"
#include "llvm/Analysis/LoopInfo.h"
#include "llvm/Analysis/LoopIterator.h"
#include "llvm/Analysis/LoopPass.h"
#include "llvm/Analysis/LoopInfoImpl.h"
#include "llvm/ADT/APInt.h"

using namespace llvm;
FunctionCallee vtrace;
std::vector<llvm::Value *> args;

namespace{
    
    struct MyLoopPass : public FunctionPass{
        static char ID;
        
        MyLoopPass() : FunctionPass(ID) {}
        
        
        void getAnalysisUsage(AnalysisUsage &AU) const override {
            
            AU.addRequired<LoopInfoWrapperPass>();
        }
        
        virtual bool runOnFunction(Function &F) override
        {
            auto M = F.getParent();
            
            LoopInfo *LI = &getAnalysis<LoopInfoWrapperPass>().getLoopInfo();
            errs().write_escaped(F.getName());
            errs() << "\n";
            
            for(Function::iterator BB = F.begin(), E = F.end(); BB != E; ++BB)
            {
                BasicBlock* b = &*BB;
                bool isLoop = LI->getLoopFor(b);
                bool isHeader = LI->isLoopHeader(b);
                if (isHeader)
                {
                    MyLoopPass::runOnBasicBlock(BB, M);
                }
            }
            return true;
        }
        
        virtual bool runOnBasicBlock(Function::iterator &BB, Module *M)
        {
            args.clear();
            for(BasicBlock::iterator BI = BB->begin(), BE = BB->end(); BI != BE; ++BI)
            {
                if(isa<ICmpInst>(&(*BI)) )
                {
                    int opCount = 0;
                    for (auto op = BI->op_begin(); op != BI->op_end(); op++){
                        opCount ++;
                        errs() << "args: " << op->get()->getName() << " -- " << op->get()->getType() << "\n";
                        args.push_back(op->get());
                    }
                    
                    std::string funName = "vtrace" + std::to_string(opCount);
                    
                    vtrace = M->getOrInsertFunction(funName, Type::getVoidTy(M->getContext())
                                                    , Type::getInt32Ty(M->getContext()),
                                                    Type::getInt32Ty(M->getContext()));
                    //Type::getInt8PtrTy(F.getContext()),
                }
                
                
            }
            return true;
        }
        
        
    };
    
    struct LoopTransformPass : public LoopPass{
        static char ID;
        
        LoopTransformPass() : LoopPass(ID) {}
        
        void getAnalysisUsage(AnalysisUsage &AU) const override {
            
            AU.addRequired<LoopInfoWrapperPass>();
        }
        
        virtual bool runOnLoop (Loop *L, LPPassManager &LPM) override{
            LoopInfo *LI = &getAnalysis<LoopInfoWrapperPass>().getLoopInfo();
            for (Loop::block_iterator BB = L->block_begin(), E = L->block_end(); BB != E; ++BB)
            {
                BasicBlock* b = *BB;
                bool isLoop = LI->getLoopFor(b);
                bool isHeader = LI->isLoopHeader(b);
                if(isLoop && !isHeader){
                    errs() << "inside loop\n";
                    for(BasicBlock::iterator BI = b->begin(), BE = b->end(); BI != BE; ++BI)
                    {
                        if(isa<LoadInst>(&(*BI)) )
                        {
                            LoadInst *CI = dyn_cast<LoadInst>(BI);
                            llvm::ArrayRef<llvm::Value *> argsRef(args);
                            Instruction *newInst = CallInst::Create(vtrace, argsRef, "");
                            Instruction* pi = (Instruction*)CI;
                            errs() << "inject vtrace function inside loop\n" ;
                            b->getInstList().insert(pi->getIterator() , newInst);
                        }
                    }
                }
            }
            
            return true;
        }
        
//        virtual bool runOnFunction(Function &F) override
//        {
//            LoopInfo *LI = &getAnalysis<LoopInfoWrapperPass>().getLoopInfo();
//            errs().write_escaped(F.getName());
//            errs() << "\n";
//
////            auto *DTWP = getAnalysisIfAvailable<DominatorTreeWrapperPass>();
////            auto *DT = DTWP ? &DTWP->getDomTree() : nullptr;
//            for(Function::iterator BB = F.begin(), E = F.end(); BB != E; ++BB)
//            {
//                BasicBlock* b = &*BB;
//                bool isLoop = LI->getLoopFor(b);
//                bool isHeader = LI->isLoopHeader(b);
//                if(isLoop && !isHeader){
//                    errs() << "inside loop\n";
//                    LoopTransformPass::runOnBasicBlock(BB);
//                }
//            }
//            return true;
//        }

//        virtual bool runOnBasicBlock(Function::iterator &BB)
//        {
//            for(BasicBlock::iterator BI = BB->begin(), BE = BB->end(); BI != BE; ++BI)
//            {
//                if(isa<LoadInst>(&(*BI)) )
//                {
//                    LoadInst *CI = dyn_cast<LoadInst>(BI);
//                    llvm::ArrayRef<llvm::Value *> argsRef(args);
//                    Instruction *newInst = CallInst::Create(vtrace, argsRef, "");
//                    Instruction* pi = (Instruction*)CI;
//                    errs() << "inject vtrace function inside loop\n" ;
//                    BB->getInstList().insert(pi->getIterator() , newInst);
//                }
//            }
//            return true;
//        }
        
        
    };
    
}

char MyLoopPass::ID = 0;
char LoopTransformPass::ID = 1;

static RegisterPass<LoopTransformPass> X("LoopTransformPass", "transform pass for injecting vtrace() inside each loop", false, false);
static RegisterPass<MyLoopPass> X1("MyLoopPass", "Lookup in each loop to create vtrace function", false, false);


