class MyConst{
     final static String jlInteger = "java/lang/Integer";
     final static String jlStringBuilder = "java/lang/StringBuilder";
     final static String jlDouble = "java/lang/Double";
     final static String jlFloat = "java/lang/Float";
}
