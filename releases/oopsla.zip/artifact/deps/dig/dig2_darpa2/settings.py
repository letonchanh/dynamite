import vu_common as CM
tmpdir = "/var/tmp/"
logger_level = CM.VLog.DEBUG
logger_printtime = True
doMP = True
inpMaxV = None
solver_timeout = None
