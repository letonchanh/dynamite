import vu_common as CM
logger_level = CM.VLog.DEBUG
tmpdir = "/var/tmp/"
