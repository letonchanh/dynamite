/*same as Fig 4_3 Gulwani pldi 09*/
