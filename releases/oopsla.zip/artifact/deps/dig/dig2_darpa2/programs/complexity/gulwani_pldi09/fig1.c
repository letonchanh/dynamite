/*See code in pldi Fig4_1*/
