/* *** I don't really know what this dir = fwd means so cannot try this example*** */
