prog=geo1     
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 10

prog=geo2     
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 10

prog=geo3     
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/nla/$prog.c  -log 3 -seed 10

