prog=gulwani_pldi09/ex6.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_popl09/Fig4_1.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10




prog=gulwani_cav09/fig1a.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_cav09/fig1d.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_cav09/fig2a.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_cav09/fig2d.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_cav09/fig3a.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_cav09/fig5b.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10


prog=gulwani_pldi09/fig1.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_pldi09/fig2.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_pldi09/fig4_1.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_pldi09/fig4_2.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_pldi09/fig4_3.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_pldi09/fig4_4.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_pldi09/fig4_5.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_popl09/Fig2_1.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_popl09/Fig2_2.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_popl09/
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_popl09/Fig3_4.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10


prog=gulwani_popl09/Fig4_2.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_popl09/Fig4_3.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10

prog=gulwani_popl09/Fig4_4.c
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 0
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 1
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 2
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 3
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 4
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 5
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 6
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 7
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 8
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 9
timeout 10m $SAGE/sage -python -O dig2.py programs/complexity/$prog  -log 3 -seed 10
