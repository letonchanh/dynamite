#!/bin/bash
FILES=programs/hola/*.c
